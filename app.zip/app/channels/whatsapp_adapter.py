from __future__ import annotations
from datetime import datetime
from typing import Any, List
from app.channels.base import UnifiedMessage

class WhatsAppAdapter:
    @staticmethod
    def extract_messages(payload: dict[str, Any]) -> List[UnifiedMessage]:
        """
        Meta webhook payload → список UnifiedMessage.
        Поддержка: text, audio/voice (media_id).
        """
        out: List[UnifiedMessage] = []

        entry = payload.get("entry", [])
        for e in entry:
            changes = e.get("changes", [])
            for ch in changes:
                value = ch.get("value", {})
                messages = value.get("messages", [])
                for m in messages:
                    wa_id = (m.get("from") or "").strip()  # это external_user_id
                    msg_id = (m.get("id") or "").strip()

                    m_type = m.get("type")
                    ts = m.get("timestamp")
                    created_at = datetime.utcnow()

                    if m_type == "text":
                        text = (m.get("text", {}) or {}).get("body")
                        out.append(
                            UnifiedMessage(
                                channel="whatsapp",
                                external_user_id=wa_id,
                                message_id=msg_id,
                                message_type="text",
                                text=text,
                                created_at=created_at,
                            )
                        )

                    elif m_type in ("audio", "voice"):
                        media = m.get(m_type, {}) or {}
                        out.append(
                            UnifiedMessage(
                                channel="whatsapp",
                                external_user_id=wa_id,
                                message_id=msg_id,
                                message_type="audio",
                                media_id=media.get("id"),
                                mime_type=media.get("mime_type"),
                                created_at=created_at,
                            )
                        )

        return out