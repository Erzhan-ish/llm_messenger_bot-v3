# app/processing/slots.py

from typing import Dict, Optional

DEFAULT_SLOTS = {
    "debtor_type": None,        # ФЛ / ЮЛ
    "account_type": None,       # ОСНОВНОЙ / ЗАДАТКОВЫЙ / ЗАЛОГОВЫЙ / СПЕЦ
    "procedure_type": None,     # процедура
    "email": None,
    "documents_ready": None,    # True / False
}
CRITICAL_SLOTS = {
    "debtor_type",    # физ / юр
    "account_type",   # основной / спец / задатковый
    "procedure",      # наблюдение / конкурс / реализация
    "email",          # контактная почта (текстом)
}



def extract_slots(text: str, slots: Dict) -> Dict:
    t = text.lower()

    # debtor_type
    if "физ" in t:
        slots["debtor_type"] = "ФЛ"
    if "юр" in t:
        slots["debtor_type"] = "ЮЛ"

    # account_type
    if "основ" in t:
        slots["account_type"] = "ОСНОВНОЙ"
    if "задат" in t:
        slots["account_type"] = "ЗАДАТКОВЫЙ"
    if "залог" in t or "заголов" in t:
        slots["account_type"] = "ЗАЛОГОВЫЙ"
    if "спец" in t:
        slots["account_type"] = "СПЕЦ"

    # documents_ready
    if t in ("да", "есть", "имеются"):
        slots["documents_ready"] = True
    if t in ("нет", "не готовы"):
        slots["documents_ready"] = False

    # email (простейший детект)
    if "@" in t and "." in t:
        slots["email"] = text.strip()

    return slots


def next_missing_slot(slots: dict) -> str | None:
    for slot in CRITICAL_SLOTS:
        if not slots.get(slot):
            return slot
    return None