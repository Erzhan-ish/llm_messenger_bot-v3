# app/processing/message_processor.py
from __future__ import annotations

import os
import random
import re
from typing import Optional

from app.context.session_manager import get_or_create_session, reset_session
from app.processing.state_detector import detect_state, DialogState
from app.storage.repositories.messages_repo import save_message, get_messages_by_session
from app.storage.repositories.sessions_repo import (
    set_negative_handled,
    get_slots,
    set_slots,
    touch_session_activity,
    get_client_need,
    set_client_need,
)
from app.processing.dedup import is_duplicate_message
from app.processing.rate_limit import check_rate_limit, RateLimitExceeded
from app.outbound.dispatcher import OutboundDispatcher
from app.services.transcription_service import transcribe_audio
from app.logging import logger

from app.services.client_need_detector import detect_client_need

from app.processing.slots import DEFAULT_SLOTS, extract_slots
from app.processing.slot_questions import QUESTIONS
from app.processing.triggers import (
    AGGRESSIVE_REPLIES,
    NEGATIVE_REPLIES,
    END_DIALOG_PHRASES,
    SHORT_NEUTRAL,
    TRIGGERS,
)

from app.llm.prompts.manager.loader import build_manager_system_prompt
from app.context.context_builder import build_context
from app.knowledge_base.service import get_kb_snippets
from app.llm.providers import ask_llm

# Если хочешь полностью отключить эскалацию пока, просто оставь False
ENABLE_ESCALATION_CALL = True

# Если Bitrix сейчас комментишь, это не должно ломать диалог
try:
    from app.escalation.service import escalate_to_manager  # type: ignore
except Exception:
    escalate_to_manager = None  # type: ignore


manager_nickname = "Алексей"
scenario = "INBOUND_QUESTION"

# ----------------------------
# Smalltalk / intent router
# ----------------------------
_INTENT_RE = {
    "greeting": re.compile(r"^(привет|здравствуйте|здарова|добрый\s*(день|вечер|утро)|hi|hello)\b", re.I),
    "who_are_you": re.compile(r"\b(кто\s*вы|ты\s*кто|как\s*тебя\s*зовут|представ(ься|тесь))\b", re.I),
    "help": re.compile(r"^(help|помоги|что\s*ты\s*умеешь|что\s*можешь)\b", re.I),
    "thanks": re.compile(r"\b(спасибо|благодарю|thx|thanks)\b", re.I),
    "bye": re.compile(r"^(пока|до\s*свидания|увидимся|bye|bb)\b", re.I),
    "stop": re.compile(r"^(стоп|хватит|прекрати|не\s*пиши|замолчи)\b", re.I),
}

_WS = re.compile(r"\s+")


def _normalize_text(text: str) -> str:
    t = (text or "").strip()
    t = _WS.sub(" ", t)
    return t


def detect_smalltalk_intent(text: str) -> Optional[str]:
    t = _normalize_text(text).lower()
    if not t:
        return "empty"
    for name, rx in _INTENT_RE.items():
        if rx.search(t):
            return name
    return None


# ----------------------------
# Intent / mode
# ----------------------------
def detect_onboarding_intent(text: str) -> bool:
    t = (text or "").lower()
    return any(x in t for x in TRIGGERS)


def normalize_mode(slots: dict, text: str) -> str:
    """
    INFO = отвечаем на вопросы по базе знаний
    ONBOARDING = собираем 4 слота для открытия счета
    """
    mode = slots.get("_mode") or "INFO"
    if mode != "ONBOARDING" and detect_onboarding_intent(text):
        mode = "ONBOARDING"
    return mode


# ----------------------------
# Slot parsing helpers
# ----------------------------
def parse_documents_ready(text: str) -> Optional[bool]:
    t = (text or "").strip().lower()
    yes = {"да", "есть", "готовы", "готово", "имеются", "имеется", "собраны", "собрал"}
    no = {"нет", "не готовы", "не готово", "не готов", "пока нет", "ещё нет", "еще нет"}
    if t in yes:
        return True
    if t in no:
        return False
    return None


def is_timing_question(text: str) -> bool:
    t = (text or "").lower()
    return any(x in t for x in ["как долго", "сколько", "срок", "за сколько", "в течение", "когда"])


def next_missing_slot_for_onboarding(slots: dict) -> Optional[str]:
    required = ["account_type", "debtor_type", "procedure_type", "documents_ready"]
    for k in required:
        if slots.get(k) is None:
            return k
    return None


def is_ready_for_escalation(slots: dict) -> bool:
    required = ["account_type", "debtor_type", "procedure_type", "documents_ready"]
    return all(slots.get(k) is not None for k in required)


# ----------------------------
# Clean / safety for answers (NO hallucinations, NO 3rd person)
# ----------------------------
BAD_PREFIX_RE = re.compile(r"(?is)^\s*(ответ\s*:|цитата\s*:)\s*")
THIRD_PERSON_RE = re.compile(
    r"(?is)\b(я\s+буду\s+отвечать|клиент\s+спросил|не\s+вижу\s+информации|уточню\s+у\s+менеджера)\b"
)


def cleanup_text(text: str) -> str:
    if not text:
        return ""

    t = text.strip()

    # убрать "Ответ:"
    t = BAD_PREFIX_RE.sub("", t).strip()

    # убрать кавычки-обвязку
    t = t.strip(" \n\r\t\"'“”«»")

    # убрать "я буду отвечать", "клиент спросил" и т.п. (это ломает диалог)
    t = THIRD_PERSON_RE.sub("", t).strip()

    # убрать двойные пробелы
    t = re.sub(r"[ \t]{2,}", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)

    return t.strip()


def split_user_questions(text: str) -> list[str]:
    """
    Разбиваем сообщение на "вопросы/части", чтобы не игнорировать вторую часть.
    """
    t = (text or "").strip()
    if not t:
        return []

    # Сначала по пустым строкам
    parts = [p.strip() for p in re.split(r"\n{2,}", t) if p.strip()]
    out: list[str] = []

    for p in parts:
        # Если в куске несколько вопросов — режем по '?'
        if p.count("?") >= 2:
            buf = []
            for chunk in re.split(r"(\?)", p):
                buf.append(chunk)
                if chunk == "?":
                    q = "".join(buf).strip()
                    buf = []
                    if q:
                        out.append(q)
            tail = "".join(buf).strip()
            if tail:
                out.append(tail)
        else:
            out.append(p)

    return out or [t]


# ----------------------------
# Intro once reliably
# ----------------------------
async def send_bot(session, channel: str, external_user_id: str, text: str, slots: dict) -> dict:
    # Интро показываем один раз на сессию (храним в slots)
    if not slots.get("_introduced"):
        text = f"Это {manager_nickname}.\n\n" + (text or "")
        slots["_introduced"] = True
        await set_slots(session.id, slots)

    text = (text or "").strip()
    if not text:
        text = "Принял."

    await save_message(session.id, "bot", text, channel)
    await OutboundDispatcher.send(channel=channel, external_user_id=external_user_id, text=text)
    return slots


# ----------------------------
# Escalation (safe, non-blocking)
# ----------------------------
async def maybe_escalate(session_id: int, slots: dict, reason: str) -> None:
    """
    Эскалация должна сработать:
    - когда пользователь хочет открыть счет (ONBOARDING) и слоты собраны
    - ИЛИ когда вопрос не про открытие счета / просто консультация — тоже эскалируем в конце ответа
    ВАЖНО: не меняем статус сессии, чтобы не плодить новые сессии.
    """
    if slots.get("_escalation_sent"):
        return

    # пометим, чтобы не дергать повторно
    slots["_escalation_sent"] = True
    slots["_escalation_reason"] = reason
    await set_slots(session_id, slots)

    if not ENABLE_ESCALATION_CALL:
        return

    if escalate_to_manager is None:
        return

    try:
        await escalate_to_manager(session_id)
    except Exception:
        # не роняем воркер
        logger.exception("escalate_to_manager failed (ignored)")


# ----------------------------
# LLM answering strictly by KB
# ----------------------------
async def answer_by_kb_strict(question: str, session_id: int, kb_snippets: str) -> tuple[str, bool]:
    """
    Возвращает (answer, has_kb).
    Если KB не найден — НЕ вызываем LLM (чтобы не галлюцинировал).
    """
    if not (kb_snippets or "").strip():
        return "", False

    history_context = await build_context(session_id)

    system_prompt = build_manager_system_prompt().replace("{MANAGER_NICKNAME}", manager_nickname)

    user_payload = [
        f"SCENARIO={scenario}",
        f"MANAGER_NICKNAME={manager_nickname}",
        "ВАЖНО: отвечай ТОЛЬКО по базе знаний ниже. Ничего не придумывай.",
        "Если в базе знаний нет ответа — скажи ровно: 'По этому вопросу сейчас нет информации в базе знаний. Я не буду придумывать.'",
        "",
        "База знаний (фрагменты):",
        kb_snippets,
    ]

    if history_context:
        user_payload.extend(["", "Контекст диалога:", history_context])

    user_payload.extend(["", "Вопрос клиента:", question])

    user_payload.append(
        """
Требования к стилю:
- Пиши от первого лица, как менеджер (никакого "клиент спросил", "я буду отвечать", "уточню у менеджера").
- Без слова "Ответ:" и без цитирования.
- Если вопрос составной — ответь на оба пункта.
- Будь конкретным: цифры/сроки/условия — как в базе знаний.
"""
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "\n".join(user_payload)},
    ]

    try:
        llm_reply = await ask_llm(messages)
    except Exception:
        logger.exception("ask_llm failed")
        llm_reply = ""

    reply = cleanup_text(llm_reply)

    # страховка: если модель выдала пустоту — вернем хотя бы что-то
    if not reply:
        reply = "По этому вопросу сейчас есть информация в базе знаний, но я не смог корректно сформировать ответ. Передам менеджеру."

    return reply, True


async def process_message(message):
    print("RUNNING message_processor FROM:", __file__, "PID:", os.getpid())

    if isinstance(message, dict):
        from app.channels.base import UnifiedMessage
        message = UnifiedMessage(**message)

    # 0️⃣ Dedup
    if await is_duplicate_message(
        channel=message.channel,
        external_user_id=message.external_user_id,
        external_message_id=message.message_id,
    ):
        return

    # 1️⃣ Rate limit
    try:
        await check_rate_limit(
            channel=message.channel,
            external_user_id=message.external_user_id,
            limit=6,
            window_seconds=10,
        )
    except RateLimitExceeded:
        return

    # 2️⃣ /reset
    if message.text and message.text.strip() == "/reset":
        await reset_session(message.channel, message.external_user_id)
        await OutboundDispatcher.send(
            channel=message.channel,
            external_user_id=message.external_user_id,
            text="Контекст диалога сброшен. Начнём заново.",
        )
        return

    # 3️⃣ Session
    session = await get_or_create_session(
        channel=message.channel,
        external_user_id=message.external_user_id,
    )

    # обновим активность, чтобы не терять сессию
    try:
        await touch_session_activity(session.id)
    except Exception:
        logger.exception("touch_session_activity failed (ignored)")

    # 4️⃣ Audio → text
    if message.message_type == "audio" and not message.text:
        try:
            message.text = await transcribe_audio(message.audio_path)
        except Exception:
            slots = await get_slots(session.id) or DEFAULT_SLOTS.copy()
            slots["_mode"] = slots.get("_mode") or "INFO"
            await send_bot(
                session,
                message.channel,
                message.external_user_id,
                "Не получилось распознать голосовое. Напишите текстом.",
                slots,
            )
            return

    # 5️⃣ Save inbound
    await save_message(
        session_id=session.id,
        role="user",
        text=message.text,
        channel=message.channel,
        external_message_id=message.message_id,
    )

    user_text = _normalize_text(message.text or "")
    text_norm = user_text.lower()

    # 5.1️⃣ Smalltalk intents BEFORE negative/state and BEFORE KB
    smalltalk = detect_smalltalk_intent(user_text)
    if smalltalk:
        slots = await get_slots(session.id) or DEFAULT_SLOTS.copy()
        slots["_mode"] = slots.get("_mode") or "INFO"

        if smalltalk == "empty":
            await send_bot(session, message.channel, message.external_user_id, "Я не увидел текст. Напишите вопрос 🙂", slots)
            return

        if smalltalk == "greeting":
            await send_bot(
                session,
                message.channel,
                message.external_user_id,
                "Привет! Чем могу помочь? Опишите вопрос — отвечу по базе знаний.",
                slots,
            )
            return

        if smalltalk == "who_are_you":
            await send_bot(
                session,
                message.channel,
                message.external_user_id,
                f"Я {manager_nickname}, менеджер по сопровождению. Задайте вопрос — отвечу по базе знаний.",
                slots,
            )
            return

        if smalltalk == "help":
            await send_bot(
                session,
                message.channel,
                message.external_user_id,
                "Могу подсказать по базе знаний, уточнить детали и помочь с оформлением/вопросами по продуктам. Напишите запрос.",
                slots,
            )
            return

        if smalltalk == "thanks":
            await send_bot(session, message.channel, message.external_user_id, "Пожалуйста 🙂 Если появятся вопросы — пишите.", slots)
            return

        if smalltalk == "bye":
            await send_bot(session, message.channel, message.external_user_id, "Хорошо, обращайтесь 🙂", slots)
            return

        if smalltalk == "stop":
            # не “ломаем” диалог и не меняем статусы — просто прекращаем инициативу
            await send_bot(session, message.channel, message.external_user_id, "Ок. Не буду писать без запроса. Если нужно — просто задайте вопрос.", slots)
            return

    # 6️⃣ Завершение диалога (только явные фразы)
    # ВАЖНО: не используем это как "заморозку" — просто вежливо заканчиваем.
    if text_norm in END_DIALOG_PHRASES:
        slots = await get_slots(session.id) or DEFAULT_SLOTS.copy()
        await send_bot(
            session,
            message.channel,
            message.external_user_id,
            "Хорошо, понял. Если появятся вопросы — напишите.",
            slots,
        )
        await maybe_escalate(session.id, slots, reason="dialog_end")
        return

    # 7️⃣ Негатив / агрессия
    if text_norm in SHORT_NEUTRAL:
        state = DialogState.IN_PROGRESS
    else:
        state = detect_state(user_text)

    if state in (DialogState.NEGATIVE, DialogState.AGGRESSIVE):
        if not session.negative_handled:
            slots = await get_slots(session.id) or DEFAULT_SLOTS.copy()
            reply = random.choice(NEGATIVE_REPLIES if state == DialogState.NEGATIVE else AGGRESSIVE_REPLIES)
            await send_bot(session, message.channel, message.external_user_id, reply, slots)
            await set_negative_handled(session.id, True)
            await maybe_escalate(session.id, slots, reason="negative_or_aggressive")
        return

    # 8️⃣ Slots + mode
    slots = await get_slots(session.id) or DEFAULT_SLOTS.copy()
    slots = extract_slots(user_text, slots)

    mode = normalize_mode(slots, user_text)
    slots["_mode"] = mode

    # сохраняем documents_ready только в ONBOARDING и только если ещё нет значения
    if mode == "ONBOARDING" and slots.get("documents_ready") is None:
        dr = parse_documents_ready(user_text)
        if dr is not None:
            slots["documents_ready"] = dr

    await set_slots(session.id, slots)

    # 9️⃣ ONBOARDING: сбор 4 слотов (без LLM)
    if mode == "ONBOARDING":
        if is_ready_for_escalation(slots):
            await send_bot(
                session,
                message.channel,
                message.external_user_id,
                "Информацию зафиксировал. Передаю менеджеру для открытия счёта.",
                slots,
            )
            await maybe_escalate(session.id, slots, reason="onboarding_ready")
            return

        missing = next_missing_slot_for_onboarding(slots)
        if missing:
            q = QUESTIONS.get(missing, "Уточните, пожалуйста, деталь по вашему запросу.")
            await send_bot(session, message.channel, message.external_user_id, q, slots)
            return

        await send_bot(session, message.channel, message.external_user_id, "Принял. Продолжаю оформление.", slots)
        return

    # ============================
    # 10️⃣ INFO: ответы строго по KB (без галлюцинаций)
    # ============================
    questions = split_user_questions(user_text)
    answers: list[str] = []
    had_unknown = False

    for q in questions:
        q = q.strip()
        if not q:
            continue

        kb_snippets = get_kb_snippets(q, top_k=5) or ""
        if not kb_snippets.strip():
            had_unknown = True
            answers.append("По этому вопросу сейчас нет информации в базе знаний. Я не буду придумывать.")
            continue

        a, _ = await answer_by_kb_strict(q, session.id, kb_snippets)
        a = cleanup_text(a)
        if not a:
            had_unknown = True
            a = "По этому вопросу сейчас нет информации в базе знаний. Я не буду придумывать."
        answers.append(a)

    if not answers:
        answers = ["По этому вопросу сейчас нет информации в базе знаний. Я не буду придумывать."]
        had_unknown = True

    if len(answers) == 1:
        final_reply = answers[0]
    else:
        final_reply = "\n\n".join([f"{i+1}) {ans}" for i, ans in enumerate(answers)])

    await send_bot(session, message.channel, message.external_user_id, final_reply, slots)

    # после любого INFO-ответа — эскалируем (по твоему требованию)
    await maybe_escalate(session.id, slots, reason="info_answer_unknown" if had_unknown else "info_answer")

    # 11️⃣ Определение потребности (фоном)
    try:
        if not await get_client_need(session.id):
            msgs = await get_messages_by_session(session.id)
            dialog_text = "\n".join(f"{m['role']}: {m['text']}" for m in msgs if m.get("text"))
            need = await detect_client_need(dialog_text)
            if need and need != "UNKNOWN":
                await set_client_need(session.id, need)
    except Exception:
        logger.exception("client_need detection failed (ignored)")
