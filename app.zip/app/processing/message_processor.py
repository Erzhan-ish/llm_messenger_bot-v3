from app.context.session_manager import get_or_create_session, reset_session
from app.context.context_builder import build_context
from app.knowledge_base.service import get_kb_snippets
from app.llm.prompts.manager.loader import build_manager_system_prompt
from app.processing.state_detector import detect_state, DialogState
from app.storage.repositories.messages_repo import save_message
from app.storage.repositories.sessions_repo import set_negative_handled
from app.processing.dedup import is_duplicate_message
from app.processing.rate_limit import check_rate_limit, RateLimitExceeded
from app.outbound.dispatcher import OutboundDispatcher
from app.services.transcription_service import transcribe_audio
from app.logging import logger
import random
import datetime
from app.services.client_need_detector import detect_client_need
from app.storage.repositories.sessions_repo import set_client_need
from app.storage.repositories.messages_repo import get_messages_by_session
from app.storage.repositories.sessions_repo import get_client_need

from app.processing.slots import DEFAULT_SLOTS, extract_slots, next_missing_slot
from app.processing.slot_questions import QUESTIONS
from app.storage.repositories.sessions_repo import get_slots, set_slots, set_dialog_state, mark_escalated
from  app.processing.slots import CRITICAL_SLOTS


from app.escalation.service import (
    is_ready_for_escalation,
    escalate_to_manager
)
from app.llm.providers import ask_llm

manager_nickname = "Алексей"
scenario = "INBOUND_QUESTION"

AGGRESSIVE_REPLIES = [
    "Понял. Прекращаю общение.",
    "Сообщения прекращаю.",
    "Принял. Больше писать не буду.",
    "Хорошо, прекращаю контакт.",
    "Общение завершено.",
]

END_DIALOG_PHRASES = {
    "все",
    "всё",
    "все спасибо",
    "всё спасибо",
    "спасибо",
    "на этом все",
    "на этом всё",
    "до свидания",
}

SHORT_NEUTRAL = {"да", "есть", "счет", "почта", "ок", "угу"}

NEGATIVE_REPLIES = [
    "Понял, больше не беспокою. Если понадобится — напишите.",
    "Хорошо, не буду писать. Обращайтесь при необходимости.",
    "Принял, прекращаю сообщения. Если появятся вопросы — на связи.",
]

def apply_intro_once(session, reply: str) -> str:
    if session.dialog_state == "new":
        return f"Это {manager_nickname}.\n\n" + reply
    return reply


async def process_message(message):
    if isinstance(message, dict):
        from app.channels.base import UnifiedMessage
        message = UnifiedMessage(**message)

    # 0️⃣ Dedup
    if await is_duplicate_message(
        channel=message.channel,
        external_user_id=message.external_user_id,
        external_message_id=message.message_id,
    ):
        return

    # 1️⃣ Rate limit
    try:
        await check_rate_limit(
            channel=message.channel,
            external_user_id=message.external_user_id,
            limit=5,
            window_seconds=10,
        )
    except RateLimitExceeded:
        return

    # 2️⃣ /reset
    if message.text and message.text.strip() == "/reset":
        await reset_session(message.channel, message.external_user_id)
        await OutboundDispatcher.send(
            channel=message.channel,
            external_user_id=message.external_user_id,
            text="Контекст диалога сброшен. Начнём заново.",
        )
        return

    # 3️⃣ Session
    session = await get_or_create_session(
        channel=message.channel,
        external_user_id=message.external_user_id,
    )

    # 4️⃣ Audio → text
    if message.message_type == "audio" and not message.text:
        try:
            message.text = await transcribe_audio(message.audio_path)
        except Exception:
            await OutboundDispatcher.send(
                channel=message.channel,
                external_user_id=message.external_user_id,
                text="Не получилось распознать голосовое. Напишите текстом.",
            )
            return

    # 5️⃣ Save inbound
    await save_message(
        session_id=session.id,
        role="user",
        text=message.text,
        channel=message.channel,
        external_message_id=message.message_id,
    )

    text_norm = (message.text or "").strip().lower()

    # 6️⃣ Завершение диалога
    if text_norm in END_DIALOG_PHRASES:
        reply = "Понял. Тогда на этом остановимся."
        await save_message(session.id, "bot", reply, message.channel)
        await OutboundDispatcher.send(
            channel=message.channel,
            external_user_id=message.external_user_id,
            text=reply,
        )
        return

    # 7️⃣ Негатив / агрессия
    if text_norm in SHORT_NEUTRAL:
        state = DialogState.IN_PROGRESS
    else:
        state = detect_state(message.text)

    if state in (DialogState.NEGATIVE, DialogState.AGGRESSIVE):
        if not session.negative_handled:
            reply = random.choice(
                NEGATIVE_REPLIES if state == DialogState.NEGATIVE else AGGRESSIVE_REPLIES
            )
            await save_message(session.id, "bot", reply, message.channel)
            await OutboundDispatcher.send(
                channel=message.channel,
                external_user_id=message.external_user_id,
                text=reply,
            )
            await set_negative_handled(session.id, True)
        return

    # 8️⃣ SLOT ENGINE — только данные
    slots = await get_slots(session.id) or DEFAULT_SLOTS.copy()
    slots = extract_slots(message.text or "", slots)

    asked = set(slots.get("_asked", []))
    slots["_asked"] = list(asked)
    await set_slots(session.id, slots)

    # 9️⃣ Проверка CRITICAL_SLOTS
    critical_missing = [k for k in CRITICAL_SLOTS if not slots.get(k)]

    # 🚀 ЭСКАЛАЦИЯ — СРАЗУ, БЕЗ LLM
    if not critical_missing:
        await mark_escalated(session.id)
        # await escalate_to_manager(session.id)

        reply = "Спасибо, информацию зафиксировал. Передаю запрос дальше, вернёмся с ответом."

        if session.dialog_state == "new":
            reply = f"Это {manager_nickname}.\n\n" + reply
            await set_dialog_state(session.id, "introduced")
            session.dialog_state = "introduced"

        await save_message(session.id, "bot", reply, message.channel)
        await OutboundDispatcher.send(
            channel=message.channel,
            external_user_id=message.external_user_id,
            text=reply,
        )
        return

    # 🔟 Один следующий слот
    missing_slot = next(
        (k for k in CRITICAL_SLOTS if not slots.get(k) and k not in asked),
        None
    )

    if missing_slot:
        asked.add(missing_slot)
        await set_slots(
            session.id,
            {**slots, "_asked": list(asked)}
        )

    # 1️⃣1️⃣ Контекст для LLM
    history_context = await build_context(session.id)
    kb_snippets = get_kb_snippets(message.text, top_k=5) or ""

    system_prompt = build_manager_system_prompt().replace(
        "{MANAGER_NICKNAME}", manager_nickname
    )

    user_payload = [
        f"SCENARIO={scenario}",
        f"MANAGER_NICKNAME={manager_nickname}",
    ]

    if kb_snippets:
        user_payload.append("KB:\n" + kb_snippets)

    if history_context:
        user_payload.append("История диалога:\n" + history_context)

    user_payload.append("Сообщение клиента:\n" + (message.text or ""))

    if missing_slot:
        user_payload.append(
            f"""
Сначала ответь на вопрос клиента, если он есть.
Затем задай ОДИН короткий вопрос ТОЛЬКО про: {missing_slot}.

Запрещено:
– документы, файлы, реквизиты
– более одного вопроса
– повтор ранее заданных вопросов
"""
        )
    else:
        user_payload.append("Не задавай вопросов.")

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "\n\n".join(user_payload)},
    ]

    # 1️⃣2️⃣ LLM
    try:
        reply = await ask_llm(messages)
    except Exception:
        reply = "Хорошо, вернёмся к этому позже."

    if session.dialog_state == "new":
        reply = f"Это {manager_nickname}.\n\n" + reply
        await set_dialog_state(session.id, "introduced")
        session.dialog_state = "introduced"

    await save_message(session.id, "bot", reply, message.channel)
    await OutboundDispatcher.send(
        channel=message.channel,
        external_user_id=message.external_user_id,
        text=reply,
    )

    # 1️⃣3️⃣ Определение потребности (фоном)
    if not await get_client_need(session.id):
        msgs = await get_messages_by_session(session.id)
        dialog_text = "\n".join(
            f"{m['role']}: {m['text']}" for m in msgs if m["text"]
        )
        need = await detect_client_need(dialog_text)
        if need != "UNKNOWN":
            await set_client_need(session.id, need)


    # 1️⃣2️⃣ Эскалация (по готовности)
    # if await is_ready_for_escalation(session.id):
    #     await escalate_to_manager(session.id)

