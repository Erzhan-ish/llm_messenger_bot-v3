from fastapi import APIRouter
from app.schemas.incoming import TgUpdate
from app.channels.telegram_adapter import TelegramAdapter
from app.logging import logger
from app.processing.message_processor import process_message

router = APIRouter(prefix="/webhook/telegram", tags=["telegram"])


@router.post("/")
async def telegram_webhook(update: TgUpdate):
    msg = update.message
    if not msg or not msg.text:
        return {"ok": True}

    text = msg.text.strip()
    chat_id = str(msg.chat.id)     # <-- КЛЮЧЕВО: куда отвечать
    from_id = str(msg.from_.id)    # <-- можно логировать, но НЕ использовать для reply

    logger.info(
        "Telegram update | chat_id={} | from_id={} | text={}",
        chat_id,
        from_id,
        text,
    )

    # /start и deep-link payload
    if text.startswith("/start"):
        payload = text.replace("/start", "").strip() or None
        unified = TelegramAdapter.build_start_message(
            external_user_id=chat_id,
            payload=payload,
        )
        await process_message(unified)
        return {"ok": True}

    unified = TelegramAdapter.to_unified(update)
    if not unified:
        return {"ok": True}

    await process_message(unified)
    return {"ok": True}
