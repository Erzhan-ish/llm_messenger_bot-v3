import asyncio
from datetime import datetime
from dataclasses import asdict

from app.logging import logger
from app.processing.message_processor import process_message
from app.storage.repositories.jobs_repo import fetch_and_lock_jobs, mark_done, retry_or_give_up
from app.channels.base import UnifiedMessage
from app.jobs.enqueue import enqueue_inbound_message_job
from app.stt.transcription_service import transcribe_audio, STTConfig
from app.config import settings


def _payload_to_unified(payload: dict) -> UnifiedMessage:
    created_at = payload.get("created_at")
    if isinstance(created_at, str):
        created_at = datetime.fromisoformat(created_at)

    return UnifiedMessage(
        channel=payload["channel"],
        external_user_id=payload["external_user_id"],
        message_id=payload["message_id"],
        message_type=payload["message_type"],
        media_id=payload.get("media_id"),
        mime_type=payload.get("mime_type"),
        text=payload.get("text"),
        audio_path=payload.get("audio_path"),
        created_at=created_at or datetime.utcnow(),
    )


async def handle_job(job):
    if job.job_type == "inbound":
        msg = _payload_to_unified(job.payload)
        await process_message(msg)
        return

    if job.job_type == "stt":
        msg = _payload_to_unified(job.payload)

        if not msg.audio_path:
            raise ValueError("STT job missing audio_path")

        cfg = STTConfig(
            engine=settings.STT_ENGINE,
            model_name=settings.STT_MODEL_NAME,
            device=settings.STT_DEVICE,
            compute_type=settings.STT_COMPUTE_TYPE,
        )

        text = await transcribe_audio(msg.audio_path, cfg)

        # Новый inbound-job, но уже text
        next_msg = UnifiedMessage(
            channel=msg.channel,
            external_user_id=msg.external_user_id,
            message_id=f"{msg.message_id}:stt",
            message_type="text",
            text=text,
            media_id=None,
            mime_type=None,
            audio_path=None,
            created_at=datetime.utcnow(),
        )
        await enqueue_inbound_message_job(next_msg)
        return

    raise ValueError(f"Unknown job_type: {job.job_type}")


async def worker_loop(poll_interval: float = 0.7, batch_size: int = 10):
    logger.info("Worker started")

    while True:
        jobs = await fetch_and_lock_jobs(limit=batch_size)
        if not jobs:
            await asyncio.sleep(poll_interval)
            continue

        for job in jobs:
            try:
                logger.info("Job running | id={} | type={}", job.id, job.job_type)
                await handle_job(job)
                await mark_done(job.id)
                logger.info("Job done | id={}", job.id)
            except Exception as e:
                logger.exception("Job failed | id={}", job.id)
                await retry_or_give_up(job.id, str(e), backoff_seconds=10)

        await asyncio.sleep(0)


def main():
    asyncio.run(worker_loop())


if __name__ == "__main__":
    main()
