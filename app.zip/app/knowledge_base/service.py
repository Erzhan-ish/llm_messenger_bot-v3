from __future__ import annotations

import re
from .loader import get_kb


def _kb_query_variants(q: str) -> list[str]:
    q = (q or "").strip()
    if not q:
        return []

    variants: list[str] = [q]

    # 0,2% -> 0.2%
    variants.append(q.replace(",", "."))

    # убрать пробелы вокруг %
    variants.append(re.sub(r"\s*%\s*", "%", q))
    variants.append(re.sub(r"\s*%\s*", "%", q.replace(",", ".")))

    # если в вопросе есть числа/проценты — добавим как ключи поиска
    nums = re.findall(r"\d+[.,]?\d*\s*%?", q)
    for n in nums:
        n2 = n.replace(" ", "")
        variants.append(n2)
        variants.append(n2.replace(",", "."))

    # уникализируем
    out: list[str] = []
    seen: set[str] = set()
    for v in variants:
        v = v.strip()
        if v and v not in seen:
            out.append(v)
            seen.add(v)
    return out


def get_kb_snippets(query: str, *, top_k: int | None = None) -> str:
    """Return formatted KB snippets for a query. Empty string if disabled/no matches."""
    kb = get_kb()
    if not kb:
        return ""

    k = top_k or 5
    all_chunks = []

    for qv in _kb_query_variants(query):
        chunks = kb.search(qv, top_k=k)
        if chunks:
            all_chunks.extend(chunks)

    if not all_chunks:
        return ""

    # дедуп (по id или тексту)
    uniq = []
    seen = set()
    for ch in all_chunks:
        key = getattr(ch, "id", None) or getattr(ch, "text", None) or str(ch)
        if key in seen:
            continue
        uniq.append(ch)
        seen.add(key)

    return kb.format_snippets(uniq[:k])
