from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from app.channels.base import UnifiedMessage
from app.storage.repositories.jobs_repo import enqueue_job
from app.logging import logger


def _to_payload(msg: UnifiedMessage) -> dict:
    return {
        "channel": msg.channel,
        "external_user_id": msg.external_user_id,
        "message_id": msg.message_id,
        "message_type": msg.message_type,
        "media_id": getattr(msg, "media_id", None),
        "mime_type": getattr(msg, "mime_type", None),
        "text": msg.text,
        "audio_path": msg.audio_path,
        "created_at": msg.created_at.isoformat() if msg.created_at else None,
    }

def _from_payload(payload: dict[str, Any]) -> UnifiedMessage:
    created_at = payload.get("created_at")
    if created_at:
        created_at = datetime.fromisoformat(created_at)
    else:
        created_at = datetime.utcnow()

    return UnifiedMessage(
        channel=payload["channel"],
        external_user_id=payload["external_user_id"],
        message_id=payload["message_id"],
        message_type=payload["message_type"],
        media_id=payload.get("media_id"),
        mime_type=payload.get("mime_type"),
        text=payload.get("text"),
        audio_path=payload.get("audio_path"),
        created_at=created_at,
    )

async def enqueue_inbound_message_job(msg: UnifiedMessage) -> int:
    payload = _to_payload(msg)

    job_id = await enqueue_job(
        job_type="inbound",
        payload=payload,
        run_after=None,
        max_attempts=5,
    )

    logger.info(
        "Inbound enqueued | job_id={} | channel={} | external_user_id={}",
        job_id,
        msg.channel,
        msg.external_user_id,
    )
    return job_id

async def enqueue_stt_job(msg: UnifiedMessage) -> int:
    """
    msg.message_type должен быть 'audio' и audio_path должен быть заполнен.
    """
    job_id = await enqueue_job(job_type="stt", payload=_to_payload(msg), max_attempts=5)
    logger.info("Job enqueued | id={} | type=stt", job_id)
    return job_id

__all__ = [
    "enqueue_inbound_message_job",
    "enqueue_stt_job",
    "_from_payload",
]

